import { Component,OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { APIService } from 'src/app/service/apiservice';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent implements OnInit{
  public appPages = [
    { title: 'My Cards', url: '/folder/mycards', icon: 'card' },
    { title: 'Profile', url: '/folder/profile', icon: 'profile' },
    { title: 'settings', url: '/folder/favorites', icon: 'spaner' },
  ];
  public labels = ['Logout'];
  public empname = '';
  constructor(private http: HttpClient, private apiservice: APIService) {}

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  ngOnInit(): void {

    this.apiservice.getClients().subscribe(
      x=>{console.log(x);}
    );

    // this.apiservice.getEmp().subscribe(
    //   x=>{console.log(x);}
    // );

    // this.apiservice.getuserapi().subscribe(
    //   x=>{console.log(x);}
    // );

  }


}
