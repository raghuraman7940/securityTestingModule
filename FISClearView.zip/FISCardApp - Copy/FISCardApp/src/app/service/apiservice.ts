import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json' , 
  })
};


@Injectable({
  providedIn: 'root'
})
export class APIService {

  constructor(private httpClient: HttpClient) { }

  getClients(): Observable<any[]> {
    return this.httpClient.get<any>('assets/client.json');
    //return this.httpClient.get<any[]>(this.api+ '/users/');
  }


  GetUserDetails(userid: any): Observable<any[]> {
    return this.httpClient.get<any>('assets/GetUserDetails.json');    
  }

  GetCards(userid: any): Observable<any[]> {
    return this.httpClient.get<any>('assets/GetCards.json');    
  }
  
  GetCardDetails(cardID: any): Observable<any[]> {
    return this.httpClient.get<any>('assets/GetCardDetails.json');    
  }

  GetOffers(bankID: any): Observable<any[]> {
    return this.httpClient.get<any>('assets/GetOffers.json');    
  }

  GetTranscations(bankID: any): Observable<any[]> {
    return this.httpClient.get<any>('assets/GetTranscations.json');    
  }

  getEmp(): Observable<any[]> {
    let url = "https://dummy.restapiexample.com/api/v1/employee/1";
    return this.httpClient.get<any>(url); 
  }

  getapiClients(): Observable<any[]> {
    return this.httpClient.get<any>('assets/client.json');
    //return this.httpClient.get<any[]>(this.api+ '/users/');
  }

  getuserapi(): Observable<any[]> {
    return this.httpClient.get<any>("http://localhost:8000/users/1");
    //return this.httpClient.get<any[]>(this.api+ '/users/');
  }


}
