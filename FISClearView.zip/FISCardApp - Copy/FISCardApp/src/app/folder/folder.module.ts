import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FolderPageRoutingModule } from './folder-routing.module';

import { FolderPage } from './folder.page';
import { MyCards } from './mycards/mycards.component';
import { MyCardDetail } from './mycarddetail/mycarddetail.component';
import { SmartstmtComponent } from './smartstmt/smartstmt.component';
import { PaymenthistoryComponent } from './paymenthistory/paymenthistory.component';
import { TxnanalogyComponent } from './txnanalogy/txnanalogy.component';
import { PostxndetailComponent } from './postxndetail/postxndetail.component';
import { OnlinetxndetailComponent } from './onlinetxndetail/onlinetxndetail.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FolderPageRoutingModule,


  ],
  declarations: [FolderPage, MyCards,MyCardDetail,
    SmartstmtComponent,PaymenthistoryComponent,TxnanalogyComponent,
    PostxndetailComponent,OnlinetxndetailComponent]
})
export class FolderPageModule {}
