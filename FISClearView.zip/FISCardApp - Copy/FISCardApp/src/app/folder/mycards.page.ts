import { Component, inject, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { APIService } from 'src/app/service/apiservice';
import { NavController } from "ionic-angular";
import { MyCardDetail } from './mycarddetail.page';
@Component({
  selector: 'app-mycards',
  templateUrl: './mycards.page.html',
  styleUrls: ['./mycards.page.scss'],
})
export class MyCards implements OnInit {
  public folder!: string;
  private activatedRoute = inject(ActivatedRoute);
  cards: any[]=[];
  mycarddetail: MyCardDetail
//private navCtrl = inject(NavController);


  constructor( private apiservice: APIService,public router: Router) {}

  ngOnInit() {
    //this.folder = this.activatedRoute.snapshot.paramMap.get('id') as string;
    this.apiservice.GetCards(1).subscribe(a => {
      this.cards = a;
    })
  }

  onCardClick(cardid: string)
  {
    //this.router.navigate(['/folder/mycarddetail',cardid]);
    //this.router.navigateByUrl(`/folder/mycarddetail/` + cardid);
	
	//this.navCtrl.setRoot(this.mycarddetail);
  }
}

