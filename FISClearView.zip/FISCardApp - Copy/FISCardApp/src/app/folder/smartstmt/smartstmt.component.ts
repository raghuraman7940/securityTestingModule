import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { APIService } from 'src/app/service/apiservice';

@Component({
  selector: 'app-smartstmt',
  templateUrl: './smartstmt.component.html',
  styleUrls: ['./smartstmt.component.scss'],
})
export class SmartstmtComponent  implements OnInit {
  cardid: string="";
  cardname!: string;
  private activatedRoute = inject(ActivatedRoute);

  public cards: any;
  public txns: any[] = [];
  constructor( private apiservice: APIService, private router: Router) { }

  ngOnInit() {
    this.cardid = this.activatedRoute.snapshot.paramMap.get('id') as string;
    this.apiservice.GetCardDetails(this.cardid).subscribe(a => {
      this.cards = a;
      console.log(this.cards);
      this.apiservice.GetTranscations(this.cardid).subscribe(b=>{
        this.txns = b;
      })
    })
  }

  ontxnclick(txnid:number,transtype:string)
  {
    if (transtype=="POS")
    this.router.navigate(['/folder/postxndetail',txnid]);
  else
  this.router.navigate(['/folder/onlinetxndetail',txnid]);
  }

}
