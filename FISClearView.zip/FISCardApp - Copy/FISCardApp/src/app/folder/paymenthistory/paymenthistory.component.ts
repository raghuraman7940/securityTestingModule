import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { APIService } from 'src/app/service/apiservice';

@Component({
  selector: 'app-paymenthistory',
  templateUrl: './paymenthistory.component.html',
  styleUrls: ['./paymenthistory.component.scss'],
})
export class PaymenthistoryComponent  implements OnInit {

  payments: any[] = [{
    "month" : "August",
    "amount" : 150,
  },
  {
    "month" : "July",
    "amount" : 100,
  },
  {
    "month" : "June",
    "amount" : 54,
  },
]
cardid: string="";
cardname!: string;
private activatedRoute = inject(ActivatedRoute);

public cards: any;
constructor( private apiservice: APIService) { }

ngOnInit() {
  this.cardid = this.activatedRoute.snapshot.paramMap.get('id') as string;
  this.apiservice.GetCardDetails(this.cardid).subscribe(a => {
    this.cards = a;
    console.log(this.cards);
  })
}

}
