import { Component, inject, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { APIService } from 'src/app/service/apiservice';

@Component({
  selector: 'app-mycarddetail',
  templateUrl: './mycarddetail.page.html',
  styleUrls: ['./mycarddetail.page.scss'],
})
export class MyCardDetail implements OnInit {
  cardid: string="";
  cardname!: string;
  private activatedRoute = inject(ActivatedRoute);

   cards: any;



  constructor( private apiservice: APIService) {}

  ngOnInit() {
    this.cardid = this.activatedRoute.snapshot.paramMap.get('id') as string;
    this.apiservice.GetCardDetails(this.cardid).subscribe(a => {
      this.cards = a;
    })
  }
}

