import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { APIService } from 'src/app/service/apiservice';
@Component({
  selector: 'app-postxndetail',
  templateUrl: './postxndetail.component.html',
  styleUrls: ['./postxndetail.component.scss'],
})
export class PostxndetailComponent  implements OnInit {
  txnid: string="";
  cardname!: string;
  private activatedRoute = inject(ActivatedRoute);

  public cards: any;
  public txn: any;
  constructor( private apiservice: APIService) { }

  ngOnInit() {
    this.txnid = this.activatedRoute.snapshot.paramMap.get('id') as string;
      this.apiservice.GetTranscations(this.txnid).subscribe(b=>{
        this.txn = b[parseInt(this.txnid)];
      })
  }
}
