import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FolderPage } from './folder.page';
import { MyCards } from './mycards/mycards.component';
import { MyCardDetail } from './mycarddetail/mycarddetail.component';
import { SmartstmtComponent } from './smartstmt/smartstmt.component';
import { PaymenthistoryComponent } from './paymenthistory/paymenthistory.component';
import { PostxndetailComponent } from './postxndetail/postxndetail.component';
import { OnlinetxndetailComponent } from './onlinetxndetail/onlinetxndetail.component';
const routes: Routes = [
  {
    path: 'mycards',
    component: MyCards
  },
  {
    path: 'mycarddetail/:id',
    component: MyCardDetail
  },
  {
    path: 'smartstmt/:id',
    component: SmartstmtComponent
  },
  {
    path: 'paymenthistory/:id',
    component: PaymenthistoryComponent
  },{
    path: 'postxndetail/:id',
    component: PostxndetailComponent
  },{
    path: 'onlinetxndetail/:id',
    component: OnlinetxndetailComponent
  },
  {
    path: '',
    component: FolderPage
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FolderPageRoutingModule {}
