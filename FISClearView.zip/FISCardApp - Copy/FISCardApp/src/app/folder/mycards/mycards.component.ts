import { Component, inject, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { APIService } from 'src/app/service/apiservice';
//import { NavController } from "ionic-angular";

@Component({
  selector: 'app-mycards',
  templateUrl: './mycards.component.html',
  styleUrls: ['./mycards.component.scss'],
})
export class MyCards implements OnInit {
  public folder!: string;
  private activatedRoute = inject(ActivatedRoute);
  cards: any[]=[];
 // mycarddetail: MyCardDetail
//private navCtrl = inject(NavController);


  constructor( private apiservice: APIService,public router: Router) {}

  ngOnInit() {
    //this.folder = this.activatedRoute.snapshot.paramMap.get('id') as string;
    this.apiservice.GetCards(1).subscribe(a => {
      this.cards = a;
    })
  }

  onCardClick(cardid: string)
  {
    this.router.navigate(['/folder/mycarddetail',cardid]);
  }
}

