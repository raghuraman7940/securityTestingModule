import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-txnanalogy',
  templateUrl: './txnanalogy.component.html',
  styleUrls: ['./txnanalogy.component.scss'],
})
export class TxnanalogyComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
