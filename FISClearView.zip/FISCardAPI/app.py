from fastapi import FastAPI, HTTPException
from urllib import parse
from sqlalchemy import create_engine, Column, Integer, String, select, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from pydantic import BaseModel
import pyodbc
from fastapi.middleware.cors import CORSMiddleware
import time
import datetime 
 

Database_url = "mssql+pyodbc:////Driver={ODBC Driver 18 for SQL Server};Server=tcp:localhost,1433;Database=FIScardappDB;Uid=sa;Pwd=Testing@1234;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;"
app = FastAPI()

origins = ["*"]

app.add_middleware(
    CORSMiddleware,    allow_origins=origins,    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
	return{"message": "hello 'The Pack Team' - Mani will give sema treat..!"}




connecting_string = 'Driver={SQL Server};Server=tcp:localhost,1433;Database=FIScardappDB;Uid=sa;Pwd=Testing@1234;'
params = parse.quote_plus(connecting_string)

engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)
engine.connect()

SessionLocal = sessionmaker(autoflush=True, bind=engine)


def fetchtbl(handle1):
    if(handle1=="GetUserDetails" or handle1=="GetCards"):
        return("Pack_GetUserCardDetails")
    elif(handle1=="GetCardDetails"):
        return("Pack_GetUserCardStmtDetails")
    elif(handle1=="GetTranscations"):
        return("Pack_GetTranscations")
    elif(handle1=="GetOffers"):
        return("Pack_GetOffers")
    else:
        return("invalid")

def fetchfields(handle1):
    if(handle1=="GetUserDetails"):
        return("Userid,UserName,UserEmail,UserMobile")
    elif(handle1=="GetCards"):
        return("Userid,Cardnum,CardID,CardType,BankName,BankId")
    elif(handle1=="GetCardDetails"):
        return("BillingSDate,Cardnum,CardID,AmtSpend,TotalDue")
    elif(handle1=="GetTranscations"):
        return("txndate,Amount,TxnDescription,Transtype,MerchantName,MerchantGeoLocation,MerchantCategory")
    elif(handle1=="GetOffers"):
        return("BankID,Offer,LastDate,Active")
    else:
        return("invalid")

def fetchclause(handle1):
    if(handle1=="GetUserDetails" or handle1=="GetCards"):
        return("Userid")
    elif(handle1=="GetCardDetails" or   handle1=="GetTranscations"):
        return("Cardnum")
    elif(handle1=="GetOffers"):
        return("BankID")
    else:
        return("invalid")

def jsonres(strvals,resdata):
	d1={}
	a = strvals.split(",")
	for i in range (0,len(a)):
		d1[a[i]] = resdata[i]
	return d1	
	
	
	

@app.get("/pack/{handle1}/{byval}")
def read(handle1,byval):
	user_details_all=[]
	db = SessionLocal()
	cols=fetchfields(handle1)
	tblval=fetchtbl(handle1)
	whereclause=fetchclause(handle1)
	strqry="Select distinct "+cols+" from "+tblval+"(Nolock) where "+whereclause+"= :byval"
	query = text(strqry)
	try:
		result = db.execute(query, {"byval": byval})
		user_data = result.fetchone()
		if user_data is None:
			raise HTTPException(status_code=404, detail="Data Not Found")
		else:
			user_details = jsonres(cols,user_data)
			user_details_all.append(user_details)
		for row in result:
			user_details = jsonres(cols,row)
			user_details_all.append(user_details)
		if len(user_details_all) == 1:
			return user_details_all[0]
		else:
			return user_details_all
	finally:
		db.close()
